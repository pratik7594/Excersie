import UIKit

var str = "Hello, playground"

//Write a Swift program to create a new string where all the character "a" have been removed except the first and last positions.

func getModifedString(input:String) -> String
{
    var inputValue = input
    let startIndex = inputValue.index(inputValue.startIndex, offsetBy: 1)
    let endIndex = inputValue.index(before: inputValue.endIndex)
    let newString = inputValue.replacingOccurrences(of: "a", with:"", options: NSString.CompareOptions.literal, range: startIndex..<endIndex)
    return newString
}

var aa = getModifedString(input: "asaaayza")
print(aa)

//Write a Swift program to create a Swift program to count the number of 7's in a given array of integers. Eg. [1, 7, 7, 4, 7] Output: 3

func getCount(input:[Int]) -> Int
{
    var i = 0
    for elemnts in input {
        if elemnts == 7 {
            i+=1
        }
    }
    return i
}

var x = getCount(input: [1,2,7,6,7,7])
print(x)

//How do you check if two strings are equal in Swift?
    let str1 = "hello"
    let str2 = "hello"
    let isEqual = (str1 == str2)

//Create a mutable dictionary named secretIdentities where the key value pairs are "Hulk" -> "Bruce Banner", "Batman" -> "Bruce Wayne", and "Superman" -> "Clark Kent".

var mutableDict: [String: String] = ["Hulk": "Bruce Banner", "Batman" : "Bruce Wayne","Superman" : "Clark Kent"]

//Using if, print "It's too hot" if the temperature is 30 degrees or above. Print "It's too cold" if the temperature is less than 0 degrees. Finally, print "It's tolerable" for any other temperature.

let currentTemp = 30

if currentTemp >=  30 {
    print("It's too hot")
} else if currentTemp < 0 {
    print("It's too cold")
}
else
{
    print ("It's tolerable")
}

//Write a Swift program that accept two integer values and return true if one of them is 20 or if their sum is 20.

func equateNumbers(x: Int, y: Int) -> Bool {
    if (x + y == 20 || x == 20 || y == 20)
    {
        return true
    }
    else
    {
        return false
    }
}

var num  = equateNumbers(x: 10, y: 30)
print(num)


//Write a Swift program to compute the sum of the two integers. If the values are equal return the triple their sum.

func equateNumbers(num1: Int, num2: Int) -> Int {
    if (num1 == num2)
    {
        return num1 + num2
    }
    else
    {
        return 3 * ( num1 + num2)
    }
}


//Write a Swift program to create a string taking characters at indexes 0, 2, 4, 6, 8, .. from a given string.

func getEvenCharacters(inputString:String) -> String
{
    let arr = Array(inputString)
      var x = ""
    for (index,elements) in arr.enumerated() {
      
        if index % 2 == 0 {
            x.append(elements)
        }
        
    }
    
    return x
}

var ss = getEvenCharacters(inputString:"qwertyterer")

//Write a Swift program to find the largest number among three given integers.

func highestNum(a:Int,b:Int,c:Int) -> Int
{
    let first = max(a,b)
    let second = max(first, c)
    return second
}

var n = highestNum(a: 20, b: 40, c: 130)

//Write a Swift program that return true if either of two given integers is in the range 10..30 inclusive.

func inRange(num:Int,num1:Int) -> Bool
{
    if num >= 10 && num <= 30 {
        return true
    } else if  num1 >= 10 && num1 <= 30 {
        return true
    }
    else
    {
        return false
    }
}

var val = inRange(num: 30, num1: 30)

//Write a Swift program to check if a given non-negative number is a multiple of 3 or a multiple of 5.

func isDivsible(num:Int)-> Bool
{
    if num % 3 == 0 || num % 5 == 0 {
        return true
    } else {
        return false
    }
}

var val1 = isDivsible(num: 9)


// Functions

//Write a function named countdown that takes a number N. The function should print the numbers from N to 1 with a one second pause in between and then write GO! in the end. To make the computer wait for one second call thesleep function from the standard library. The sleep function takes one parameter, the number of seconds to sleep.

func countdown(_ N: Int) {
    var i = N

    while i > 0 {
        print(i)

        sleep(1)

        i -= 1
    }

    print("GO!")
}

countdown(2)

//2.Write a function named timeDifference. It takes as input four numbers that represent two times in a day and returns the difference in minutes between them. The first two parameters firstHour and firstMinute represent the hour and minute of the first time. The last two secondHour and secondMinute represent the hour and minute of the second time. All parameters should have external parameter names with the same name as the local ones.*/

func timeDifference(firstHour : Int , firstMinute : Int ,secondHour : Int, secondMinute : Int ) -> Int {
    
    let hourDiffrence = firstHour - secondHour
    let minuteDiffrence = firstMinute - secondMinute
    let timeDiffrenceInMinute = (hourDiffrence * 60 ) + minuteDiffrence
    return timeDiffrenceInMinute
}
let firstHour = 4
let firstMinute = 40
let secondHour = 2
let secondMinute = 20

print(timeDifference(firstHour: firstHour, firstMinute: firstMinute, secondHour: secondHour, secondMinute: secondMinute))

//Write a function named parse(digit:) that takes a string with one character as parameter. The function should return -1 if the input is not a digit character and the digit otherwise.

func parse(digit:String) -> Int
{
    for character in digit{
        if character.isNumber{
            return character.wholeNumberValue ?? 0
        }
    }
    return -1
}

var number = parse(digit:"234")

//Implement a function named repeatPrint that takes a string message and a integer count as parameters. The function should print the message count times and then print a newline.

func repeatPrint(input:String,count:Int)
{
    for _ in 1...count
    {
        print(input)
    }
    print("\n")
}

repeatPrint(input: "Hello", count: 5)

//Write a function sum that takes a variable number of integers as input and returns the sum of the numbers.

func getSum(inputNumber:Int) -> Int
{
    var sum = 0
    var input = inputNumber
    
    while input != 0 {
        
        sum = sum + input % 10
        input = input/10
    }
    
    return sum
}

var sumNum = getSum(inputNumber: 23)

//Write a function whoAmI that takes a name as input parameter. If the name is "Bruce Wayne", the function should return "I am Batman", otherwise return "I am not Batman". The input parameter should have a default value of "Bruce Wayne".

func whoAmI(inputString:String = "Bruce Wayne") -> String
{
    if (inputString == "Bruce Wayne") {
        return "I am Batman"
    } else {
        return "I am not Batman"
    }
}

//Write a function square that takes an Int as input, but doesn't require a label at the call site, i.e. square(3) should work. It should return the square of the input value.

func square(_ N:Int) -> Int
{
   return N * N
}

var sss = square(10)

//Write a function greet that takes the first name and last name of a person (e.g. "Donald" and "Trump") as two separate input parameters and prints a greeting to that person (e.g. "Hello, Donald Trump!").

func greet(first:String,second:String)
{
    print("Hello,\(first) \(second)!")
}

greet(first: "Donald", second: "Trump")

//Write a function greeting that takes the name of a person (e.g. "Donald Trump") as input and returns a greeting string (e.g. "Hello, Donald Trump!") that can be printed.

func greeting(name:String)
{
    print("Hello,\(name)!")
}

greeting(name: "Donald Trump")

//Write a function named printHelloWorld that takes no arguments and returns nothing. It should print "Hello, World!".

func printHelloWorld()
{
    print("Hello, World!")
}
